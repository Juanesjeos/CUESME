///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

import 'package:flutter/material.dart';


class NewScreen extends StatelessWidget {

@override
Widget build(BuildContext context) {
return Scaffold(
)
;}
}