///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

import 'package:flutter/material.dart';


class intento extends StatelessWidget {

@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: Color(0xffffffff),
body:Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:SingleChildScrollView(
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Padding(
padding:EdgeInsets.fromLTRB(0, 55, 0, 20),
child:Align(
alignment:Alignment(-0.8, -0.3),
child:Text(
"Profesionales",
textAlign: TextAlign.center,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w500,
fontStyle:FontStyle.normal,
fontSize:24,
color:Color(0xff272727),
),
),
),
),

ListView(
scrollDirection: Axis.vertical,
padding:EdgeInsets.all(0),
shrinkWrap:true,
physics:ScrollPhysics(), 
children:[


Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 16),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional-08.jpg",
fit:BoxFit.cover),
),
],),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Paula García",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicóloga clínica",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:11,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x56ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),

Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 16),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional-03.jpg",
fit:BoxFit.cover),
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Lucas Gómez",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:13,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicólogo social",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x56ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),

Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 16),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional-02.jpg",
fit:BoxFit.cover),
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Sara Vélez",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicóloga",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x57ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),

Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 16),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional_Mesa-de-trabajo-1.jpg",
fit:BoxFit.cover),
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Lilian Montoya",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicóloga",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x56ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),

Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 16),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional-07.jpg",
fit:BoxFit.cover),
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Bob Ross",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicólogo",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x57ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),

Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 16),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional-06.jpg",
fit:BoxFit.cover),
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Miriam Toro",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicóloga",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x57ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),

Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 16),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional-05.jpg",
fit:BoxFit.cover),
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Sara Díaz",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicóloga",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x57ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),

Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 16),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional-04.jpg",
fit:BoxFit.cover),
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Marta Vélez",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicóloga",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x57ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),

Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 16),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional-10.jpg",
fit:BoxFit.cover),
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Berta Nuñez",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicóloga",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x57ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),

Card( 
margin:EdgeInsets.fromLTRB(0, 0, 0, 10),
color:Color(0xffffffff),
shadowColor:Color(0x4d939393),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(4.0),
side: BorderSide(color:Color(0x4d9e9e9e), width:1),
),
child:
Padding(
padding:EdgeInsets.all(16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
decoration: BoxDecoration(
color:Color(0xfff2f2f2),
shape:BoxShape.circle,
),
child:
Container(
height:60,
width:60,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/profesional-09.jpg",
fit:BoxFit.cover),
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Luis Castro",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 0),
child:Text(
"Psicólogo",
textAlign: TextAlign.start,
maxLines:1,
overflow:TextOverflow.ellipsis,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0xff6c6c6c),
),
),
),
],),),),
Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x56ef5350),
shape:BoxShape.circle,
),
child:
Icon(
Icons.call,
color:Color(0xffef5350),
size:16,
),
),
],),),
),
],),
Padding(
padding:EdgeInsets.fromLTRB(0, 0, 0, 20),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Padding(
padding:EdgeInsets.fromLTRB(60, 0, 0, 0),
child:Align(
alignment:Alignment(0.0, 0.0),
child:Icon(
Icons.account_box,
color:Color(0xffef5350),
size:30,
),
),
),
Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:30),
child:Icon(
Icons.sms,
color:Color(0xffef5350),
size:30,
),
),
Align(
alignment:Alignment(-0.1, -0.2),
child:Icon(
Icons.circle,
color:Color(0xffef5350),
size:30,
),
),
],),),
],),),),
)
;}
}