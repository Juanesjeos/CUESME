/// Descarga de archivos desde Flutterviz, arrastre y suelte una herramienta. Para más detalles, visite https://flutterviz.io/

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';


class animacionini extends StatelessWidget {

@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: Color(0xffffffff),
body:Padding(
padding:EdgeInsets.all(16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.center,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children: [
Align(
alignment:Alignment.center,
child:Lottie.network(
"https://lottie.host/e76b9c29-f1bc-449a-ac18-78702cd0b96f/IzGaJE88xu.json",
height:100,
width:MediaQuery.of(context).size.width,
fit:BoxFit.contain,
repeat: true,
animate: true,
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 30, 0, 60),
child:Text(
"Cuida tu salud mental",
textAlign: TextAlign.center,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w300,
fontStyle:FontStyle.normal,
fontSize:18,
color:Color(0xffad192b),
),
),
),
MaterialButton(
onPressed:(){},
color:Color(0xffffffff),
elevation:0,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(30.0),
side:BorderSide(color:Color(0xffaf192b),width:1),
),
padding:EdgeInsets.all(16),
child:Text("¡Empecemos!", style: TextStyle( fontSize:14,
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
),),
textColor:Color(0xffac182a),
height:45,
minWidth:MediaQuery.of(context).size.width * 0.5,
),
],),),
)
;}
}