/// Descarga de archivos desde Flutterviz, arrastre y suelte una herramienta. Para más detalles, visite https://flutterviz.io/

import 'package:flutter/material.dart';


class NewScreen extends StatelessWidget {

@override
Widget build(BuildContext context) {
return Scaffold(
)
;}
}