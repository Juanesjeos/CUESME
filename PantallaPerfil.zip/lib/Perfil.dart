///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

import 'package:flutter/material.dart';


class Perfil extends StatelessWidget {

@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: Color(0xffffffff),
appBar: 
AppBar(
elevation:0,
centerTitle:true,
automaticallyImplyLeading: false,
backgroundColor:Color(0x00ffffff),
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.zero,
),
title:Text(
"Perfil",
style:TextStyle(
fontWeight:FontWeight.w600,
fontStyle:FontStyle.normal,
fontSize:20,
color:Color(0xff3e3e3f),
),
),
leading: Icon(
Icons.launch,
color:Color(0xff3e3e3f),
size:20,
),
),
body:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children: [
SingleChildScrollView(
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children: [
Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children: [
SizedBox(
height:100,
width:100,
child:
Stack(
alignment:Alignment.center,
children: [
Align(
alignment:Alignment(0.0, 0.1),
child:Container(
height:100,
width:100,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.network(
 "https://image.freepik.com/free-photo/portrait-beautiful-young-woman-looking-camera_23-2147865523.jpg",
fit:BoxFit.cover),
),
),
Container(
height:120,
width:120,
clipBehavior: Clip.antiAlias,
decoration: BoxDecoration(
shape: BoxShape.circle,
),
child:Image.asset(
 "images/undraw_profile_pic_ic5t.webp",
fit:BoxFit.cover),
),
],),),
Text(
"Sergio Correa",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:18,
color:Color(0xffb74343),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 0, 0, 60),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.min,
children:[

Expanded(
flex: 1,
child: Align(
alignment:Alignment.center,
child:Text(
"@sercorrea1",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xffa5a5a5),
),
),
),
),
],),),
Padding(
padding:EdgeInsets.fromLTRB(0, 0, 0, 16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x27b1b1b1),
shape:BoxShape.circle,
),
child:
Icon(
Icons.dashboard,
color:Color(0xffd14444),
size:20,
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:Text(
"Progreso",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:16,
color:Color(0xff000000),
),
),
),
),
Icon(
Icons.arrow_forward_ios,
color:Color(0xffb74343),
size:18,
),
],),),
Padding(
padding:EdgeInsets.fromLTRB(0, 0, 0, 16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Container(
alignment:Alignment.center,
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(10),
decoration: BoxDecoration(
color:Color(0x29b1b1b1),
shape:BoxShape.circle,
),
child:
Icon(
Icons.warning,
color:Color(0xffc23737),
size:20,
),
),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:Text(
"Ayuda",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:16,
color:Color(0xff000000),
),
),
),
),
Icon(
Icons.arrow_forward_ios,
color:Color(0xffb03737),
size:18,
),
],),),
],),),
Align(
alignment:Alignment.centerLeft,
child:Container(
alignment:Alignment.center,
margin:EdgeInsets.fromLTRB(0, 110, 0, 16),
padding:EdgeInsets.all(0),
width:180,
height:50,
decoration: BoxDecoration(
color:Color(0x2eb1b1b1),
shape:BoxShape.rectangle,
borderRadius:BorderRadius.only(topRight: Radius.circular(24.0), bottomRight: Radius.circular(24.0)),
),
child:
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.min,
children:[

Icon(
Icons.logout,
color:Color(0xffc14040),
size:24,
),
Padding(
padding:EdgeInsets.fromLTRB(16, 0, 0, 0),
child:Text(
"Salir",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:16,
color:Color(0xffb73a3a),
),
),
),
],),
),),
],),),
],),
)
;}
}